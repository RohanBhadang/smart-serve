const firebaseConfig = {
  apiKey: "AIzaSyAKwo-xk2vL263xEf6RhqfgqaF5DvGrR74",
  authDomain: "homeservice-261f7.firebaseapp.com",
  projectId: "homeservice-261f7",
  storageBucket: "homeservice-261f7.firebasestorage.app",
  messagingSenderId: "733177772372",
  appId: "1:733177772372:web:33c8351164ba0fe49770c1"
};

export default firebaseConfig;